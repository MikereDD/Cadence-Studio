<p align="center">
  <img src="src/CadenceStudio.App/Assets/cadence-studio-icon-256.png" width="116" alt="Cadence Studio icon">
</p>

<h1 align="center">Cadence Studio</h1>

<p align="center">
  A premium, local-first Windows music player built with C#, WPF, XAML, MVVM, NAudio, and TagLibSharp.
</p>

<p align="center">
  <img src="https://img.shields.io/badge/version-1.0-b8872c" alt="Version 1.0">
  <img src="https://img.shields.io/badge/platform-Windows%2010%20%7C%2011-555b66" alt="Windows 10 and 11">
  <img src="https://img.shields.io/badge/.NET-8-555b66" alt=".NET 8">
  <img src="https://img.shields.io/badge/audio-NAudio%202.3.0-555b66" alt="NAudio 2.3.0">
  <img src="https://img.shields.io/badge/metadata-TagLibSharp%202.3.0-555b66" alt="TagLibSharp 2.3.0">
  <img src="https://img.shields.io/badge/UI-WPF%20%2B%20XAML-2d2d2d" alt="WPF and XAML">
</p>

## Stable release

**Cadence Studio v1.0** is the first stable release. Its installer, portable packages, upgrade path, user-data persistence, long-session playback, visualizers, compact and expanded workspaces, and final interface presentation were validated through the release-candidate cycle.

Cadence Studio is separate from **Cadence Classic**, the original PowerShell/WinForms application. The two projects have independent codebases, settings, release histories, and development paths.

## Highlights

- Local music-library indexing with real folder hierarchy and fast cached startup.
- NAudio playback with seek, volume, shuffle, repeat, queue management, and clean shutdown.
- Real-time 10-band equalizer with presets, preamp, custom profiles, and headroom protection.
- Full-spectrum FFT visualizers with multiple densities, palettes, response controls, and reduced-motion support.
- Compact and expanded Now Playing workspaces.
- Detached Window Visualizer with Celestial Resonance, Aurora Cascade, Glass Horizon, and Infinite Windows presets.
- Six isolated themes: Dark Monochrome, OLED Black, Graphite, Midnight Indigo, Obsidian Gold, and Aurora Pulse.
- Cadence, Precision, and Clear typography profiles with Standard, Large, and Extra Large sizing.
- Persistent queue, playlists, workspace, playback position, window state, theme, typography, EQ, and visualizer settings.
- M3U/M3U8 playlist import and export.
- Embedded and folder artwork, MusicBrainz matching, Cover Art Archive retrieval, LRCLIB lyrics, and Wikipedia artist information.
- Single-track and full-album Metadata Workshops with review, backups, selective writes, artwork embedding, and post-write verification.
- Global Library search across artists, albums, tracks, and genres.
- Song-change notifications with artwork, progress, and playback controls.
- About, diagnostics, logs, cache locations, and a built-in Keyboard Shortcuts reference.

## Install and run

### Windows installer

The installer is the recommended deployment. It installs per-user to:

```text
%LOCALAPPDATA%\Programs\Cadence Studio
```

It creates a Start Menu shortcut, offers an optional desktop shortcut, and preserves Cadence Studio user data during upgrades and uninstall.

### Portable release

Two portable packages are produced:

- **Self-contained:** includes the .NET runtime and runs without a separate runtime installation.
- **Framework-dependent:** smaller package that requires the .NET 8 Desktop Runtime.

### Build from source

Requirements:

- Windows 10 or Windows 11
- .NET 8 SDK

```powershell
.\build.ps1 -Run
```

Debug output is written to:

```text
src\CadenceStudio.App\bin\Debug\net8.0-windows\CadenceStudio.exe
```

## Release packaging

Portable packages only:

```powershell
.\packaging\New-Release.ps1 -SkipInstaller
```

Complete release set, including the Inno Setup installer:

```powershell
.\packaging\New-Release.ps1
```

The release script detects Inno Setup 6 from PATH, standard machine-wide locations, and the standard per-user location under `%LOCALAPPDATA%`. An explicit compiler path can also be supplied:

```powershell
.\packaging\New-Release.ps1 `
    -InnoCompilerPath "$env:LOCALAPPDATA\Programs\Inno Setup 6\ISCC.exe"
```

Generated artifacts, manifests, release notes, and SHA-256 checksums are written beneath:

```text
artifacts\release\<version>
```

## User data and privacy

Cadence Studio is local-first. It does not require an account, subscription, or mandatory cloud service.

```text
%LOCALAPPDATA%\CadenceStudio
├── session.json
├── playlists.json
├── cache
│   ├── library-index.json
│   ├── enrichment\<track-hash>.json
│   └── artwork\<musicbrainz-id>-500.jpg
└── logs\cadence-studio.log
```

Online enrichment is optional. Playback, local indexing, playlists, local metadata, and cached content remain available offline.

## Project principles

Cadence Studio aims for controlled spectacle rather than clutter: layered depth, tactile controls, expressive visualizers, strong typography, and clear hierarchy without sacrificing reliability or accessibility.

Cadence Studio v1.0 reached stable status only after fresh-install, upgrade, persistence, recovery, performance, long-playback, portable-package, installer, and uninstall validation passed.

## Documentation

- [v1.0 Validation Plan](RC-TEST-PLAN.md)
- [Testing Notes](TESTING.md)
- [Roadmap](ROADMAP.md)
- [Changelog](CHANGELOG.md)
- [Release Notes](RELEASE-NOTES.md)
- [Third-Party Notices](THIRD-PARTY-NOTICES.md)
